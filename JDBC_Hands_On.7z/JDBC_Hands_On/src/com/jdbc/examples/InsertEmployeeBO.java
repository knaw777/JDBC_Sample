/**
 * 
 */
package com.jdbc.examples;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

/**
 * @author t-Khader
 *
 */
public class InsertEmployeeBO {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// TODO Auto-generated method stub

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Employee Details");
		System.out.println("Enter the ID:");
		int employeeId = scanner.nextInt();
		System.out.println("Enter the Name:");
		String name = scanner.next();
		System.out.println("Enter the date of birth(dd/MM/yyyy)");
		String date = scanner.next();
		System.out.println("Enter the salary");
		int salary = scanner.nextInt();
		Date dob = null;
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
					"dd/MM/yyyy");
			 dob = simpleDateFormat.parse(date);
		} catch (Exception e) {
			e.printStackTrace();

		}
		Employee employee = new Employee();
		employee.setEmployeeId(employeeId);
		employee.setName(name);
		employee.setDateOfBirth(dob);
		employee.setSal(salary);
		EmployeeDAO empDao = new EmployeeDAO();
		empDao.addEmployee(employee); 
		List<Employee> employeeList =empDao.getAllEmployees();
		
		for(int i = 0 ; i<employeeList.size();i++){
			
			Employee emp = (Employee)employeeList.get(i);
			System.out.println("emp.."+emp);
			
		}
		

	}

}
