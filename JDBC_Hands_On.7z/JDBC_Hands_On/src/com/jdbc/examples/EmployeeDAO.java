/**
 * 
 */
package com.jdbc.examples;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author t-Khader
 *
 */
public class EmployeeDAO {

	public void addEmployee(Employee emp) {

		System.out.println("addEmployeee..");

		PreparedStatement prepareStatement;
		Connection conn = null;
		try {
			conn = getConnection();
			if (conn != null) {
				prepareStatement = conn
						.prepareStatement("insert into employee values(?,?,?,?)");
				prepareStatement.setInt(1, emp.getEmployeeId());
				prepareStatement.setString(2, emp.getName());
				prepareStatement.setDate(3, new java.sql.Date(emp
						.getDateOfBirth().getTime()));
				prepareStatement.setInt(4, emp.getSal());
				prepareStatement.executeUpdate();
				System.out.println("Record inserted successfully...");
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void updateEmployee(int empId, String empName) {

		PreparedStatement prepareStatement;
		System.out.println("empId:"+empId);
		System.out.println("empName:"+empName);
		Connection conn = null;
		try {
			conn = getConnection();
			if (conn != null) {
				prepareStatement = conn
						.prepareStatement("update employee set name =? where employee_id = ?");

				prepareStatement.setString(1, empName);
				prepareStatement.setInt(2, empId);

				prepareStatement.executeUpdate();
				System.out.println("Record updated successfully...");
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	
	public void deleteEmployee(int empId) {

		PreparedStatement prepareStatement;
		System.out.println("empId:"+empId);
	
		Connection conn = null;
		try {
			conn = getConnection();
			conn.setAutoCommit(false);
			if (conn != null) {
				prepareStatement = conn
						.prepareStatement("delete from employee  where employee_id = ?");

				
				prepareStatement.setInt(1, empId);

				prepareStatement.executeUpdate();
				System.out.println("Record deleted successfully...");
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} finally {
			try {
				conn.commit();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}


	public List<Employee> getAllEmployees() {

		PreparedStatement prepareStatement;
		List<Employee> empList = new ArrayList<Employee>();
		Connection conn = null;
		ResultSet resultSet;
		try {
			conn = getConnection();
			if (conn != null) {

				prepareStatement = conn
						.prepareStatement(" select employee_id,name,date_of_birth, salary from employee ");
				resultSet = prepareStatement.executeQuery();
				while (resultSet.next()) {

					int empId = resultSet.getInt("employee_id");
					String name = resultSet.getString("name");
					Date dob = resultSet.getDate("date_of_birth");
					int salary = resultSet.getInt("salary");
					Employee emp = new Employee();
					emp.setEmployeeId(empId);
					emp.setName(name);
					emp.setDateOfBirth(dob);
					emp.setSal(salary);
					empList.add(emp);

				}
			}

		} catch (SQLException se) {
			se.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println("empList.." + empList);

		return empList;

	}

	public Connection getConnection() {

		Connection connection = null;
		System.out.println("-------- MySQL JDBC Connection Demo ------------");
		try {
			//Class.forName("com.mysql.jdbc.Driver");

			System.out.println("MySQL JDBC Driver Registered!");

			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/emp_schema", "root", "password-1");
			System.out.println("SQL Connection to database established!");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;

	}

}
