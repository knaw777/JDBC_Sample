/**
 * 
 */
package com.jdbc.examples;

import java.text.SimpleDateFormat;
import java.util.List;

/**
 * @author t-Khader
 *
 */
public class GetEmployeeBO {

	public static void main(String args[]) {

		EmployeeDAO empDao = new EmployeeDAO();

		List<Employee> employeeList = empDao.getAllEmployees();

		for (int i = 0; i < employeeList.size(); i++) {

			Employee emp = (Employee) employeeList.get(i);
			
			SimpleDateFormat sdfr = new SimpleDateFormat("dd/MM/yyyy");
			
			String date_str = sdfr.format(emp.getDateOfBirth());
			System.out.println(emp.getName()+" "+date_str+" "+emp.getSal());
			//String date_str = sdfr.format(emp.getDateOfBirth());
			//System.out.println(emp.getEmployeeId()+":"+emp.getName()+":"+emp.getDateOfBirth()+":"+emp.getSal());
			//System.out.println("emp.." + emp);

		}
	}

}
