/**
 * 
 */
package com.jdbc.examples;

/**
 * @author t-Khader
 *
 */
public class UpdateEmployeeBO {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EmployeeDAO empDao = new EmployeeDAO();
		empDao.updateEmployee(2, "Mark");

	}

}
